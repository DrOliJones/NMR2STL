function start_nmr2stl()

gui